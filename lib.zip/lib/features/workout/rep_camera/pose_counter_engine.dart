import 'dart:math' as math;

enum Joint {
  leftShoulder,
  rightShoulder,
  leftElbow,
  rightElbow,
  leftWrist,
  rightWrist,
  leftHip,
  rightHip,
  leftKnee,
  rightKnee,
  leftAnkle,
  rightAnkle,
}

class JointPoint {
  final double x, y, confidence;
  const JointPoint(this.x, this.y, [this.confidence = 1]);
}

typedef Skeleton = Map<Joint, JointPoint>;

enum ExerciseKind { squat, pushUp, lunge, plank, jumpingJack, shoulderPress }

ExerciseKind? exerciseKindFromName(String input) {
  final n = input.toLowerCase().replaceAll(RegExp(r'[^a-z]'), '');
  if (n.contains('squat')) return ExerciseKind.squat;
  if (n.contains('pushup')) return ExerciseKind.pushUp;
  if (n.contains('lunge')) return ExerciseKind.lunge;
  if (n.contains('plank')) return ExerciseKind.plank;
  if (n.contains('jumpingjack')) return ExerciseKind.jumpingJack;
  if (n.contains('shoulderpress')) return ExerciseKind.shoulderPress;
  return null;
}

double? jointAngle(JointPoint? a, JointPoint? b, JointPoint? c) {
  if (a == null ||
      b == null ||
      c == null ||
      a.confidence < .55 ||
      b.confidence < .55 ||
      c.confidence < .55) {
    return null;
  }
  final uX = a.x - b.x, uY = a.y - b.y;
  final vX = c.x - b.x, vY = c.y - b.y;
  final denom = math.sqrt((uX * uX + uY * uY) * (vX * vX + vY * vY));
  if (denom < 1e-8) return null;
  final cosine = ((uX * vX + uY * vY) / denom).clamp(-1.0, 1.0);
  return math.acos(cosine) * 180 / math.pi;
}

class PoseObservation {
  final bool? contracted;
  final bool? extended;
  final bool plankAligned;
  final String cue;
  const PoseObservation({
    this.contracted,
    this.extended,
    this.plankAligned = false,
    required this.cue,
  });
}

double? _bestAngle(Skeleton p, List<(Joint, Joint, Joint)> triples) {
  final found = <double>[];
  for (final (a, b, c) in triples) {
    final angle = jointAngle(p[a], p[b], p[c]);
    if (angle != null) found.add(angle);
  }
  if (found.isEmpty) return null;
  return found.reduce((a, b) => a + b) / found.length;
}

PoseObservation observeExercise(ExerciseKind kind, Skeleton p) {
  final knees = _bestAngle(p, [
    (Joint.leftHip, Joint.leftKnee, Joint.leftAnkle),
    (Joint.rightHip, Joint.rightKnee, Joint.rightAnkle),
  ]);
  final elbows = _bestAngle(p, [
    (Joint.leftShoulder, Joint.leftElbow, Joint.leftWrist),
    (Joint.rightShoulder, Joint.rightElbow, Joint.rightWrist),
  ]);
  switch (kind) {
    case ExerciseKind.squat:
      if (knees == null) {
        return const PoseObservation(
          cue: 'Đưa toàn thân vào khung hình (nghiêng nhẹ).',
        );
      }
      return PoseObservation(
        contracted: knees < 105,
        extended: knees > 155,
        cue: 'Squat: xuống đủ sâu rồi đứng thẳng.',
      );
    case ExerciseKind.lunge:
      final lk = jointAngle(
        p[Joint.leftHip],
        p[Joint.leftKnee],
        p[Joint.leftAnkle],
      );
      final rk = jointAngle(
        p[Joint.rightHip],
        p[Joint.rightKnee],
        p[Joint.rightAnkle],
      );
      if (lk == null || rk == null) {
        return const PoseObservation(
          cue: 'Đặt camera nghiêng để thấy cả hai đầu gối và chân.',
        );
      }
      return PoseObservation(
        contracted: math.min(lk, rk) < 112,
        extended: lk > 150 && rk > 150,
        cue: 'Lunge: hạ đầu gối trước, rồi đứng thẳng lại.',
      );
    case ExerciseKind.pushUp:
      final torso = _bestAngle(p, [
        (Joint.leftShoulder, Joint.leftHip, Joint.leftAnkle),
        (Joint.rightShoulder, Joint.rightHip, Joint.rightAnkle),
      ]);
      if (elbows == null || torso == null || torso < 145) {
        return const PoseObservation(
          cue: 'Đặt camera ngang người; giữ thân thẳng, đủ tay trong hình.',
        );
      }
      return PoseObservation(
        contracted: elbows < 100,
        extended: elbows > 155,
        cue: 'Push Up: hạ thấp và đẩy lên duỗi tay.',
      );
    case ExerciseKind.shoulderPress:
      final ls = p[Joint.leftShoulder], rs = p[Joint.rightShoulder];
      final lw = p[Joint.leftWrist], rw = p[Joint.rightWrist];
      if (elbows == null ||
          ls == null ||
          rs == null ||
          lw == null ||
          rw == null ||
          [ls, rs, lw, rw].any((v) => v.confidence < .55)) {
        return const PoseObservation(
          cue: 'Đưa cả hai tay, vai và đầu vào khung hình.',
        );
      }
      final wristsUp = lw.y < ls.y && rw.y < rs.y;
      return PoseObservation(
        contracted: elbows < 110,
        extended: elbows > 150 && wristsUp,
        cue: 'Shoulder Press: đẩy tay lên rồi hạ về vai.',
      );
    case ExerciseKind.jumpingJack:
      final la = p[Joint.leftAnkle], ra = p[Joint.rightAnkle];
      final lh = p[Joint.leftHip], rh = p[Joint.rightHip];
      final ls = p[Joint.leftShoulder], rs = p[Joint.rightShoulder];
      final lw = p[Joint.leftWrist], rw = p[Joint.rightWrist];
      final pts = [la, ra, lh, rh, ls, rs, lw, rw];
      if (pts.any((v) => v == null || v.confidence < .55)) {
        return const PoseObservation(
          cue: 'Đứng xa hơn để thấy đủ tay và chân.',
        );
      }
      final hipWidth = (lh!.x - rh!.x).abs();

      if (hipWidth < 8) {
        return const PoseObservation(cue: 'Đứng đối diện camera.');
      }

      final ratio = (la!.x - ra!.x).abs() / hipWidth;

      final leftWrist = lw;
      final rightWrist = rw;

      final armsUp =
          leftWrist != null &&
          rightWrist != null &&
          leftWrist.y < ls!.y &&
          rightWrist.y < rs!.y;

      final armsDown =
          leftWrist != null &&
          rightWrist != null &&
          leftWrist.y > ls!.y &&
          rightWrist.y > rs!.y;
      return PoseObservation(
        contracted: ratio > 2.0 && armsUp,
        extended: ratio < 1.55 && armsDown,
        cue: 'Jumping Jack: dang tay-chân, rồi khép về.',
      );
    case ExerciseKind.plank:
      final torso = _bestAngle(p, [
        (Joint.leftShoulder, Joint.leftHip, Joint.leftAnkle),
        (Joint.rightShoulder, Joint.rightHip, Joint.rightAnkle),
      ]);
      final aligned = torso != null && torso >= 157 && torso <= 198;
      return PoseObservation(
        plankAligned: aligned,
        cue: aligned
            ? 'Giữ thân thẳng — đang tính thời gian.'
            : 'Plank: cần thấy vai, hông, cổ chân cùng một đường.',
      );
  }
}

/// Needs stable consecutive pose frames and full movement cycle.
/// No rep is emitted for missing/low confidence landmarks.
class RepDetector {
  final ExerciseKind exercise;
  int reps = 0;
  bool _armed = false;
  int _stableCount = 0;
  bool? _candidate;
  DateTime? _lastRep;
  RepDetector(this.exercise);

  bool update(PoseObservation pose, DateTime now) {
    if (exercise == ExerciseKind.plank) return false;
    bool? state;
    if (pose.contracted == true) state = true;
    if (pose.extended == true) state = false;
    if (state == null) {
      _stableCount = 0;
      _candidate = null;
      return false;
    }
    if (_candidate == state) {
      _stableCount++;
    } else {
      _candidate = state;
      _stableCount = 1;
    }
    if (_stableCount < 2) return false;
    if (state == true) {
      _armed = true;
      return false;
    }
    if (_armed &&
        (_lastRep == null || now.difference(_lastRep!).inMilliseconds >= 600)) {
      _armed = false;
      _lastRep = now;
      reps++;
      return true;
    }
    return false;
  }

  void reset() {
    reps = 0;
    _armed = false;
    _stableCount = 0;
    _candidate = null;
    _lastRep = null;
  }
}
